package cn.edu.neusoft.fooddemo.util;

/**
 * Created by 173.hexu 2018/12/17.
 */
public class Contants {

    public static String BASEURL = "http://192.168.43.250:8080/foodService/";
}
